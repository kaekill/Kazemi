<?php

wp_clear_scheduled_hook( 'auto_manager_check_for_expired_autos' );